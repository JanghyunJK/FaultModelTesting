# global variables suitable for all Coil:Cooling:DX object faults

$model_names = %w(Q EIR)
$other_faults = %w(CA CH CAF LL NC EF)
